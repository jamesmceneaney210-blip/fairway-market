import {NextResponse} from "next/server"; import {prisma} from "@/lib/prisma";
export async function GET(req:Request){const ids=new URL(req.url).searchParams.get("ids")?.split(",").filter(Boolean)||[];if(!ids.length)return NextResponse.json([]);return NextResponse.json(await prisma.product.findMany({where:{id:{in:ids},status:"ACTIVE"}}))}
