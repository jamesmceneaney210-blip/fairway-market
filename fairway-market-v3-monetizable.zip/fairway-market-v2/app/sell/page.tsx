import {SellForm} from "@/components/SellForm";
export default function Sell(){return <main className="container form-page"><span className="eyebrow dark">SELL YOUR GEAR</span><h1>Give your clubs<br/>a second round.</h1><p className="lede">Add the details buyers care about — shaft, loft, hand, condition and included accessories.</p><SellForm/></main>}
