import "./globals.css"; import { Header } from "@/components/Header";
export const metadata={title:"Fairway Market | Golf Resale",description:"Buy and sell pre-owned golf equipment."};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="en"><body><Header/>{children}</body></html>}
