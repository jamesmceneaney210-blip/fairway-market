"use client";
import Link from "next/link"; import {useEffect,useState} from "react";
export function Header(){const[count,setCount]=useState(0);useEffect(()=>{const f=()=>setCount(JSON.parse(localStorage.getItem("fairway-cart")||"[]").length);f();addEventListener("cart-updated",f);return()=>removeEventListener("cart-updated",f)},[]);
return <header><Link href="/" className="logo">FAIRWAY<span>MARKET</span></Link><nav><Link href="/browse">Shop</Link><Link href="/sell">Sell</Link><Link href="/dashboard">Dashboard</Link></nav><Link className="bag" href="/cart">Bag <b>{count}</b></Link></header>}
