"use client";
import { useState } from "react";
export function CheckoutButton({productId}:{productId:string}){
 const [email,setEmail]=useState(""); const [loading,setLoading]=useState(false); const [error,setError]=useState("");
 async function go(){setLoading(true);setError("");const r=await fetch('/api/checkout',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({productIds:[productId],buyerEmail:email})});const d=await r.json();if(d.url) location.href=d.url; else {setError(d.error||'Checkout failed');setLoading(false)}}
 return <div className="checkout-box"><input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Your email" type="email"/><button className="btn primary" disabled={!email||loading} onClick={go}>{loading?'Opening checkout…':'Buy securely with Stripe'}</button>{error&&<small className="error">{error}</small>}</div>
}
