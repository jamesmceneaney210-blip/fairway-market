export function money(cents:number){return new Intl.NumberFormat("en-IE",{style:"currency",currency:"EUR"}).format(cents/100)}
