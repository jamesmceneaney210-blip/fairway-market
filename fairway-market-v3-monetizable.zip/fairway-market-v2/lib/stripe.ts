import Stripe from "stripe";

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "sk_test_placeholder");

export const PLATFORM_FEE_BPS = Number(process.env.PLATFORM_FEE_BPS || 1200);
export function platformFee(amount: number) { return Math.round(amount * PLATFORM_FEE_BPS / 10000); }
