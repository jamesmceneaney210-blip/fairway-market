# Fairway Market — monetizable golf marketplace

This version turns the demo into a real marketplace starter with Stripe Checkout and Stripe Connect.

## Revenue model
The platform takes a configurable percentage of each completed sale. Default: 12% (`PLATFORM_FEE_BPS=1200`). Stripe routes the remainder to the seller's connected account.

## Setup
1. `npm install`
2. Copy `.env.example` to `.env`.
3. Add Stripe keys.
4. `npx prisma generate && npm run db:push && npm run db:seed`
5. `npm run dev`
6. Configure a Stripe webhook to `https://YOUR_DOMAIN/api/stripe/webhook` for `checkout.session.completed`.

## Production checklist
- Use PostgreSQL (change Prisma datasource provider and DATABASE_URL) rather than SQLite.
- Add real authentication and authorization before launch.
- Verify seller identity/KYC through Stripe Connect.
- Add image storage (S3/R2/Cloudinary), moderation, returns/refunds, shipping labels, tax/VAT handling, fraud controls, terms/privacy, and email notifications.
- Test Stripe webhooks and Connect payouts in test mode before enabling live keys.
