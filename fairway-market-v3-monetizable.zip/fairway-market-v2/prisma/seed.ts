import { PrismaClient } from "@prisma/client";
const prisma=new PrismaClient();
const items=[
["TaylorMade Stealth 2 Driver 10.5°","TaylorMade","Drivers","Very Good",24900,"Right","Regular","Fujikura Ventus","10.5°","45.75 in","Golf Pride","Headcover"],
["Titleist SM10 56° Wedge","Titleist","Wedges","Good",9900,"Right","Stiff","Dynamic Gold","56°","35.5 in","Golf Pride Tour Velvet",""],
["TaylorMade P790 7-Iron","TaylorMade","Irons","Excellent",11500,"Right","Stiff","N.S. Pro Modus","33°","37 in","Lamkin",""],
["TaylorMade Spider GT Putter","TaylorMade","Putters","Excellent",13900,"Right","Standard","KBS","3°","34 in","SuperStroke","Headcover"],
["Titleist Pro V1 — 12 balls","Titleist","Balls","Good",2200,"","", "", "", "", "", "12 balls"],
["Ping Tour Staff Cart Bag","Ping","Bags","Very Good",12900,"","","","","","","Rain hood"]
];
const imgs=[
"https://images.unsplash.com/photo-1592919505780-303950717480?auto=format&fit=crop&w=1200&q=80",
"https://images.unsplash.com/photo-1587174486073-ae5e5cff23aa?auto=format&fit=crop&w=1200&q=80",
"https://images.unsplash.com/photo-1535131749006-b7f58c99034b?auto=format&fit=crop&w=1200&q=80",
"https://images.unsplash.com/photo-1593111774240-d529f12cf4bb?auto=format&fit=crop&w=1200&q=80",
"https://images.unsplash.com/photo-1535132011086-b8818f016104?auto=format&fit=crop&w=1200&q=80",
"https://images.unsplash.com/photo-1622336618051-1b6f4f0b6e6b?auto=format&fit=crop&w=1200&q=80"
];
async function main(){
 const seller=await prisma.user.upsert({where:{email:"seller@fairway.local"},update:{},create:{name:"Fairway Seller",email:"seller@fairway.local"}});
 await prisma.product.deleteMany();
 for(let i=0;i<items.length;i++){const x=items[i];await prisma.product.create({data:{title:x[0] as string,brand:x[1] as string,category:x[2] as string,condition:x[3] as string,price:x[4] as number,imageUrl:imgs[i],handedness:x[5] as string,shaftFlex:x[6] as string,shaftModel:x[7] as string,loft:x[8] as string,length:x[9] as string,grip:x[10] as string,included:x[11] as string,description:"Pre-owned golf equipment inspected for listing. Please review the photos and specification details before purchase.",sellerId:seller.id}})}
}
main().finally(()=>prisma.$disconnect());
